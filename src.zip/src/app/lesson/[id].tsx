import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { styles } from "../../constants/styles";
import { lessons } from "../../data/lessons";
import { questions } from "../../data/questions";
import { Question } from "../../types";

export default function LessonDetail() {
  const { id } = useLocalSearchParams();
  const router = useRouter();

  const lesson = lessons.find((l) => l.id === Number(id));
  const lessonQuestions: Question[] = questions.filter(
    (q) => q.lessonId === Number(id),
  );

  const [currentQuestion, setCurrentQuestion] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [correctCount, setCorrectCount] = useState<number>(0); // ← Ganti nama biar jelas
  const [wrongCount, setWrongCount] = useState<number>(0); // ← BARU: hitung yang salah
  const [isFinished, setIsFinished] = useState<boolean>(false);

  useEffect(() => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setCorrectCount(0);
    setWrongCount(0);
    setIsFinished(false);
  }, [id]);

  if (!lesson) {
    return (
      <View style={styles.detailContainer}>
        <Text>Pelajaran tidak ditemukan</Text>
      </View>
    );
  }

  // Hitung total soal dan skor akhir
  const totalQuestions = lessonQuestions.length;
  const totalWordsInLesson = lesson.totalWords; // ← Ambil dari lesson
  const finalScore =
    totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;

  // Validasi: apakah jumlah soal sesuai dengan totalWords?
  const isQuestionCountMatch = totalQuestions === totalWordsInLesson;

  if (totalQuestions === 0) {
    return (
      <ScrollView style={styles.detailContainer}>
        <Text style={styles.detailTitle}>{lesson.title}</Text>
        <Text style={styles.detailSubtitle}>{lesson.englishTitle}</Text>
        <Text style={styles.detailDescription}>{lesson.description}</Text>

        <View style={styles.detailInfo}>
          <Text style={styles.detailInfoText}>
            Level: {lesson.level.toUpperCase()}
          </Text>
          <Text style={styles.detailInfoText}>
            Total Kata: {lesson.totalWords}
          </Text>
          <Text style={styles.detailInfoText}>
            Selesai: {lesson.completedWords}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>← Kembali</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  const question = lessonQuestions[currentQuestion];

  const handleAnswer = (answer: string) => {
    if (selectedAnswer) return;
    setSelectedAnswer(answer);

    if (answer === question.correctAnswer) {
      setCorrectCount(correctCount + 1); // ← Tambah yang benar
    } else {
      setWrongCount(wrongCount + 1); // ← Tambah yang salah
    }

    setTimeout(() => {
      if (currentQuestion < totalQuestions - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
        setIsFinished(true);
      }
    }, 800);
  };

  const handleFinish = () => {
    router.replace("/");
  };

  if (isFinished) {
    return (
      <View style={styles.quizContainer}>
        <Text
          style={[
            styles.quizResult,
            finalScore >= 60
              ? styles.quizResultCorrect
              : styles.quizResultWrong,
          ]}
        >
          {finalScore >= 60 ? "🎉 Hebat!" : "😅 Coba Lagi!"}
        </Text>

        <Text style={{ textAlign: "center", fontSize: 18, color: "#333" }}>
          Skor kamu: {finalScore}/100
        </Text>

        {/* Detail skor */}
        <View style={styles.detailInfo}>
          <Text style={styles.detailInfoText}>✅ Benar: {correctCount}</Text>
          <Text style={styles.detailInfoText}>❌ Salah: {wrongCount}</Text>
          <Text style={styles.detailInfoText}>
            📊 Total Soal: {totalQuestions}
          </Text>
          <Text style={styles.detailInfoText}>
            📚 Total Kata di Pelajaran: {totalWordsInLesson}
          </Text>
          {!isQuestionCountMatch && (
            <Text
              style={{
                fontSize: 12,
                color: "#E65100",
                marginTop: 8,
                fontStyle: "italic",
              }}
            >
              ⚠️ Jumlah soal ({totalQuestions}) belum sesuai dengan total kata (
              {totalWordsInLesson})
            </Text>
          )}
        </View>

        <TouchableOpacity style={styles.startButton} onPress={handleFinish}>
          <Text style={styles.startButtonText}>Kembali ke Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.quizContainer}>
      <Text style={{ textAlign: "center", color: "#666", marginBottom: 8 }}>
        Soal {currentQuestion + 1}/{totalQuestions}
      </Text>

      <Text style={styles.quizQuestion}>{question.question}</Text>

      {question.options.map((option, index) => {
        let optionStyle = [styles.quizOption];
        if (selectedAnswer) {
          if (option === question.correctAnswer) {
            optionStyle.push(styles.quizOptionCorrect);
          } else if (option === selectedAnswer) {
            optionStyle.push(styles.quizOptionWrong);
          }
        }
        return (
          <TouchableOpacity
            key={index}
            style={optionStyle}
            onPress={() => handleAnswer(option)}
            disabled={!!selectedAnswer}
          >
            <Text style={styles.quizOptionText}>{option}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
